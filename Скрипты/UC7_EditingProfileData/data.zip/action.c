Action()
{

	lr_start_transaction("UC6_ViewProfile");

	lr_start_transaction("Goto_HomePage");

	return 0;
}